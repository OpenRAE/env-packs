"""Main entry point for the APTL CLI."""

from typing import Optional

import typer

import aptl
from aptl.cli import appliance, config, container, experiment, kill, lab, runs, seat, web

app = typer.Typer(
    name="aptl",
    help="Advanced Purple Team Lab CLI",
    no_args_is_help=True,
)

app.add_typer(lab.app, name="lab")
app.add_typer(config.app, name="config")
app.add_typer(container.app, name="container")
app.add_typer(runs.app, name="runs")
app.add_typer(web.app, name="web")
app.add_typer(kill.app, name="kill")
app.add_typer(experiment.app, name="experiment")
app.add_typer(appliance.app, name="appliance")
app.add_typer(seat.app, name="seat")


def _version_callback(value: bool) -> None:
    """Print the installed version and exit when ``--version`` is passed."""
    if value:
        typer.echo(f"aptl {aptl.__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-V",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Advanced Purple Team Lab CLI."""
