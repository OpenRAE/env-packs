"""Shared constants for Compose-backed stateful realization."""

from pathlib import Path

STATEFUL_OVERRIDE_RELPATH = Path(".aptl/realization/compose.stateful.yml")
CERTIFICATE_ROOT_RELPATH = Path("config/wazuh_indexer_ssl_certs")
# The one accepted certificate-bundle producer. Adding a second needs more than
# a root path: the bundle validator in ``_stateful_certificates`` assumes this
# producer's shape throughout — the root is named ``root-ca.pem``, a manager root
# must agree with it, and identities must match a ``config/certs.yml``-shaped
# provenance document. A producer whose bundle differs in any of those fails
# validation regardless of where its root is found.
CERTIFICATE_PROVENANCE = "config/certs.yml"
REALIZATION_ADDRESS_LABEL = "org.aptl.realization.address"
REALIZATION_LIFECYCLE_LABEL = "org.aptl.realization.lifecycle"
REALIZATION_PROJECT_LABEL = "org.aptl.realization.project"
MIN_OVERRIDE_COMPOSE_VERSION = (2, 24, 4)

WAZUH_INDEXER_SERVICE = "wazuh.indexer"
WAZUH_MANAGER_SERVICE = "wazuh.manager"
OWNED_WAZUH_SERVICES = frozenset({WAZUH_INDEXER_SERVICE, WAZUH_MANAGER_SERVICE})
