/**
 * OpenTelemetry tracing for APTL MCP servers.
 *
 * Replaces the former ToolTracer JSONL system with OTel spans exported
 * via OTLP HTTP/protobuf to the OTel Collector.
 *
 * Cross-process propagation: reads `.aptl/trace-context.json` written
 * by `aptl scenario start` so that MCP tool spans share the same
 * trace_id as scenario lifecycle spans from the Python CLI.
 */

import { readFileSync, existsSync, statSync } from 'node:fs';
import { resolve } from 'node:path';

import { context, trace, Tracer, Context, SpanStatusCode, SpanKind } from '@opentelemetry/api';
import { resourceFromAttributes } from '@opentelemetry/resources';
import { NodeTracerProvider, BatchSpanProcessor } from '@opentelemetry/sdk-trace-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-proto';
import { ATTR_SERVICE_NAME } from '@opentelemetry/semantic-conventions';

let provider: NodeTracerProvider | null = null;

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

/**
 * Configure OTel TracerProvider with OTLP HTTP exporter.
 * Safe to call multiple times — subsequent calls are no-ops.
 */
export function initTracing(serverName: string): void {
  if (provider !== null) return;

  const endpoint = process.env.OTEL_EXPORTER_OTLP_ENDPOINT || 'http://localhost:4318';

  const resource = resourceFromAttributes({
    [ATTR_SERVICE_NAME]: serverName,
  });

  const exporter = new OTLPTraceExporter({
    url: `${endpoint}/v1/traces`,
  });

  provider = new NodeTracerProvider({
    resource,
    spanProcessors: [new BatchSpanProcessor(exporter)],
  });
  provider.register();

  console.error(`[OTel] Tracing initialized: service=${serverName} endpoint=${endpoint}`);
}

/**
 * Force-flush and shutdown the TracerProvider.
 *
 * Flush/shutdown errors are caught and logged — tracing teardown
 * must never crash the host process (e.g. when the Collector is
 * unreachable).
 */
export async function shutdownTracing(): Promise<void> {
  if (provider !== null) {
    try {
      await provider.forceFlush();
    } catch {
      // Collector may be unreachable — not fatal
    }
    try {
      await provider.shutdown();
    } catch {
      // Best-effort shutdown
    }
    provider = null;
    console.error('[OTel] Tracing shut down');
  }
}

/**
 * Return a Tracer from the current provider.
 */
export function getTracer(name: string = 'aptl-mcp'): Tracer {
  return trace.getTracer(name);
}

// ---------------------------------------------------------------------------
// Cross-process context
// ---------------------------------------------------------------------------

interface TraceContextFile {
  trace_id: string;
  span_id: string;
  trace_flags: string;
}

// Cache to avoid reading trace-context.json on every tool call
let cachedContext: Context | undefined;
let cachedMtimeMs: number = 0;
let cachedCtxPath: string = '';

/**
 * Read the trace context written by `aptl scenario start`.
 * Returns an OTel Context with the remote parent, or undefined if
 * no active scenario context exists.
 *
 * Results are cached by file mtime to avoid repeated disk reads
 * on every tool call.
 */
export function loadParentContext(): Context | undefined {
  const traceDir = process.env.APTL_STATE_DIR || '.aptl';
  const ctxPath = resolve(traceDir, 'trace-context.json');

  if (!existsSync(ctxPath)) {
    cachedContext = undefined;
    cachedMtimeMs = 0;
    return undefined;
  }

  // Check mtime — return cached result if file hasn't changed
  try {
    const mtimeMs = statSync(ctxPath).mtimeMs;
    if (ctxPath === cachedCtxPath && mtimeMs === cachedMtimeMs) {
      return cachedContext;
    }
    cachedCtxPath = ctxPath;
    cachedMtimeMs = mtimeMs;
  } catch {
    return cachedContext;
  }

  try {
    const raw = readFileSync(ctxPath, 'utf-8');
    const data: TraceContextFile = JSON.parse(raw);

    const spanContext = {
      traceId: data.trace_id,
      spanId: data.span_id,
      traceFlags: Number.parseInt(data.trace_flags, 16),
      isRemote: true,
    };

    // Validate hex lengths
    if (spanContext.traceId.length !== 32 || spanContext.spanId.length !== 16) {
      console.error('[OTel] Invalid trace context dimensions, ignoring');
      cachedContext = undefined;
      return undefined;
    }

    const parentSpan = trace.wrapSpanContext(spanContext);
    cachedContext = trace.setSpan(context.active(), parentSpan);
    return cachedContext;
  } catch (err) {
    console.error(`[OTel] Could not load trace context from ${ctxPath}: ${err}`);
    cachedContext = undefined;
    return undefined;
  }
}

// ---------------------------------------------------------------------------
// Tool call tracing (replaces ToolTracer.trace())
// ---------------------------------------------------------------------------

/**
 * Wrap a tool handler call with OTel span instrumentation.
 *
 * Creates a span with GenAI SIG conventions and records only tool identity
 * and content-free completion status metadata.
 */
export async function traceToolCall<T>(
  toolName: string,
  serverName: string,
  _args: Record<string, unknown>,
  handler: () => Promise<T>,
): Promise<T> {
  const tracer = getTracer();
  const parentContext = loadParentContext() || context.active();

  return tracer.startActiveSpan(
    'execute_tool',
    {
      kind: SpanKind.INTERNAL,
      attributes: {
        'gen_ai.operation.name': 'execute_tool',
        'gen_ai.tool.name': toolName,
        'gen_ai.agent.name': serverName,
        'aptl.tool.payload.recorded': false,
      },
    },
    parentContext,
    async (span) => {
      try {
        const result = await handler();
        span.setStatus({ code: SpanStatusCode.OK });
        return result;
      } catch (err) {
        span.setStatus({ code: SpanStatusCode.ERROR });
        span.addEvent('exception', {
          'exception.type': err instanceof Error ? err.name || 'Error' : 'Error',
        });
        throw err;
      } finally {
        span.end();
      }
    },
  );
}
